import React from 'react';

function Chat() {
  return <h2>Chat</h2>;
}

export default Chat;