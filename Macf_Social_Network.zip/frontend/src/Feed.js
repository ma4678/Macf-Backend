import React from 'react';

function Feed() {
  return <h2>Feed de Postagens</h2>;
}

export default Feed;